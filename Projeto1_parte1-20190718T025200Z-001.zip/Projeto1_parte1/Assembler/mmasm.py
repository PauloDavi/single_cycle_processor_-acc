"""
Universidade Federal da Paraíba - UFPB
João Pessoa, Julho de 2019
Grupo 4:
[ Lívia Regina Lima Alves,
Tarcísio José de Araújo Pereira Filho,
Thomas Mateus Santana Nunes,
Vinícius Silva Oliveira]
Prof. José Maurício Ramos de Souza Neto

Assembler MMASM
"""
from typing import List

instset: List[str] = \
    ["add",
     "sub",
     "addi",
     "subi",
     "lsr",
     "rsr",
     "clr",
     "rst",
     "mov",
     "jmp",
     "jz",
     "inc",
     "dec",
     "load",
     "store",
     "grey"]
# l/rsr -> left/right shift

registers = ['ax', 'bx', 'cx', 'dx']

r_type = [0, 1, 4, 5, 6, 7, 8, 11, 12, 15]  # r := register, processed in ALU
i_type = [2, 3, 13, 14]  # i := immediate, processed in control and/or ALU
j_type = [9, 10]  # j := jump, processed in control

file = open("assembly.asm", 'r')

asmfile = open("codigo.asm", 'w')

for elemento in file:

    elemento = elemento.lower()

    elemento = elemento.replace("\n", "")

    elemento = elemento.split(" ")

    elemento = ', '.join(elemento)

    elemento = elemento.replace(" ", "")

    elemento = elemento.split(",")

    print(elemento)

    lenght = len(elemento)

    posicaoI = instset.index(elemento[0])  # posicao for instructions

    if posicaoI == 7 and lenght == 1:

        asmfile.write(("{0:04b}".format(posicaoI)))

        asmfile.write(("{0:06b}".format(0)))

    if posicaoI in r_type and lenght == 2 and posicaoI != 7 and posicaoI != 14:

        posicaoA = registers.index(elemento[1])

        asmfile.write(("{0:04b}".format(posicaoI)))

        asmfile.write(("{0:02b}".format(posicaoA)))

        asmfile.write(("{0:02b}".format(posicaoA)))

        asmfile.write(("{0:02b}".format(posicaoA)))

    if posicaoI in r_type and (lenght == 3) and not \
            (posicaoI == 4 or posicaoI == 5 or posicaoI == 6 or posicaoI == 7 or posicaoI == 11 or posicaoI == 12):

        posicaoA = registers.index(elemento[1])

        posicaoB = registers.index(elemento[2])

        asmfile.write(("{0:04b}".format(posicaoI)))

        asmfile.write(("{0:02b}".format(posicaoA)))

        asmfile.write(("{0:02b}".format(posicaoB)))

        asmfile.write(("{0:02b}".format(posicaoA)))  # Ex.: AX + BX -> AX

    if posicaoI in i_type and lenght == 3:

        posicaoA = registers.index(elemento[1])  # posicao for register 1

        asmfile.write(("{0:04b}".format(posicaoI)))

        asmfile.write(("{0:02b}".format(posicaoA)))

        asmfile.write(("{0:04b}".format(int(elemento[2]))))

    if posicaoI in j_type and lenght == 2:

        asmfile.write(("{0:04b}".format(posicaoI)))

        asmfile.write(("{0:06b}".format(int(elemento[1]))))

    print(posicaoI, posicaoA, posicaoB, '\nLength(linha) =', len(elemento))
    # A razão é que não podemos ter, por exemplo, "MUL2 A,B", "CLR A,B" ou apenas "DIV2"
    # (uma maneira de evitarmos, pelo menos,algumas instruções inesperadas)
    # No arquivo Assembly.txt deixei algumas instruções erradas apenas para exemplificar.

    asmfile.write("\n")
file.close()
